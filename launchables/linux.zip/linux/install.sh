mkdir ~/.adb/
cp files/AdbAutoConnector.jar ~/.adb/
cp files/icon.png ~/.adb/
cp files/adb_autoconnector.desktop ~/.local/share/applications/
cp files/adb_autoconnector_configurator.desktop ~/.local/share/applications/
echo "installed!"