rm -rf ~/.adb/
rm ~/.local/share/applications/adb_autoconnector.desktop
rm ~/.local/share/applications/adb_autoconnector_configurator.desktop
echo "successfully uninstalled"