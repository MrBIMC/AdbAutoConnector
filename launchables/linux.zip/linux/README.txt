ADB-AutoConnector is an app that can search for wireless add devices available and connect to them. All you have to do is to double click on the icon.

HOW-TO:
1. Launch install.sh file(«sh install.sh»). It will put app.jar into ~/.adb/ and create .desktop files so both Connector Script and Configurator will appear in the list of installed apps.

4. click/double click icon of the app to start script/configurator. With default config app will try to check all the ips in current zone.  

configs are stored at ~/.adb-config.json
logs are stored at ~/.adb-logs