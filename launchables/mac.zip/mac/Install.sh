#!/bin/bash
mkdir ~/.adb/
cp files/AdbAutoConnector.jar ~/.adb/
echo "installed! Read README.txt file for How-To"