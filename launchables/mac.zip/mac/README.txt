ADB-AutoConnector is an app that can search for wireless add devices available and connect to them. All you have to do is to launch .command file.

HOW-TO:
1. Launch install.command file. It will put app.jar into ~/.adb/
2. Place Launcher .command files from launcher directory to the place where it’s easy to access them(in dock, for example)
4. click/double click on launcher *.command file to start script/configurator. With default config app will try to check all the ips in current zone.  

configs are stored at ~/.adb-config.json
logs are stored at ~/.adb-logs